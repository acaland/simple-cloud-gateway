#!/bin/bash

path=`pwd`

IDL_PATH=$IDL_PATH:$path:$path/astrolib

#export IDL_PATH

echo $IDL_PATH

value=`cat fit_type`
fitparams=`cat params`

echo "$value"
echo "$fitparams"

if [ $value -eq 0 ]; then
  echo "Performing theoretical SED fitting"
  idl -e "sedpar=vialactea_tap_sedfit_v7($fitparams)"
elif [ $value -eq 1 ]; then
  echo "Performing greybody thin SED fitting"
  idl -e "sedfitgrid_engine_thin_vialactea,$fitparams"
elif [ $value -eq 2 ]; then
  echo "Performing greybody thick SED fitting" 
  idl -e "sedfitgrid_engine_thick_vialactea,$fitparams"
else
  echo "Chosed SED fitting algorithm NOT valid. Please choose one of the following options: 0=theoretical, 1=greybody thin or 2=greybody thick"
fi
